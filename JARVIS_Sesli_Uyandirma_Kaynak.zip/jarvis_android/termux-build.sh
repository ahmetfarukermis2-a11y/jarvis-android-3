#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
if ! command -v studio >/dev/null 2>&1; then
  echo "HATA: 'studio' komutu bulunamadı. Önce TERMUX_KURULUM_TR.md dosyasındaki araç kurulumunu tamamla."
  exit 1
fi

echo "JARVIS proje dizini: $PROJECT_DIR"
studio build "$PROJECT_DIR"
APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  echo "
Derleme başarılı: $APK"
  if [ -d "$HOME/storage/downloads" ]; then
    cp "$APK" "$HOME/storage/downloads/JARVIS-debug.apk"
    echo "Kopyalandı: $HOME/storage/downloads/JARVIS-debug.apk"
  fi
else
  echo "Derleme komutu tamamlandı ama beklenen APK dosyası bulunamadı. Yukarıdaki çıktıyı kontrol et."
  exit 2
fi
