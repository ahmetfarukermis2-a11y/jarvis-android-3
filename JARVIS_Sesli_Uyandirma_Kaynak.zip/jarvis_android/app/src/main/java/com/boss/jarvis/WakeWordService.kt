package com.boss.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Visible, user-started wake-word listener. Android may stop it or restrict recognition on some devices. */
class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private var speaking = false
    private var destroyed = false
    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "jarvis_wake_channel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification("Uyandırma kelimesi: JARVIS")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1001, notification)
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Bu cihazda ses tanıma hizmeti bulunamadı")
            stopSelf()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { updateNotification(if (awaitingCommand) "Komutunuzu dinliyorum" else "JARVIS uyandırma kelimesini dinliyor") }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { }
            override fun onError(error: Int) { scheduleListen(900) }
            override fun onResults(results: android.os.Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                processPhrase(phrase)
                scheduleListen(if (speaking) 1500 else 350)
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) { }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) { }
        })
        scheduleListen(500)
    }

    private fun processPhrase(raw: String) {
        val phrase = raw.trim()
        if (phrase.isBlank()) return
        val normalized = phrase.lowercase(Locale("tr", "TR"))
            .replace("ı", "i").replace("İ", "i")
        val wake = when {
            normalized == "jarvis" || normalized == "hey jarvis" || normalized == "hey carvis" -> true
            normalized.startsWith("hey jarvis ") -> true
            normalized.startsWith("jarvis ") -> true
            else -> false
        }
        if (!awaitingCommand && wake) {
            val command = phrase.substringAfter(" ", "").trim().let {
                if (normalized.startsWith("hey ")) it.substringAfter(" ", "").trim() else it
            }
            if (command.isNotBlank() && !command.equals("jarvis", true)) {
                dispatchCommand(command)
            } else {
                awaitingCommand = true
                speak("Buyurun efendim.")
                updateNotification("Uyandı, komut bekleniyor")
            }
        } else if (awaitingCommand) {
            awaitingCommand = false
            if (normalized.contains("uyku modu") || normalized.contains("kendini kapat")) {
                speak("Uyku moduna geçiyorum efendim.")
                stopSelfAfterSpeech()
            } else dispatchCommand(phrase)
        }
    }

    private fun dispatchCommand(command: String) {
        val intent = Intent(ACTION_COMMAND).setPackage(packageName).putExtra(EXTRA_COMMAND, command)
        sendBroadcast(intent)
        val lower = command.lowercase(Locale("tr", "TR")).replace("ı", "i")
        when {
            lower.contains("saat kaç") || lower.contains("saat kac") -> speak("Saat ${SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())} efendim.")
            lower.contains("pilim kaç") || lower.contains("pilim kac") || lower.contains("pil durumu") -> {
                val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Pil seviyeniz yüzde $level efendim.")
            }
            lower.contains("feneri aç") || lower.contains("feneri ac") -> setTorch(true)
            lower.contains("feneri kapat") -> setTorch(false)
            lower.contains("youtube") || lower.contains("spotify") || lower.contains("ayarları aç") || lower.contains("ayarlari ac") -> speak("Bu komutu uygulama açıkken çalıştırabilirim efendim. Lütfen ekranı açın.")
            else -> speak("Komutu aldım efendim. Daha gelişmiş işlemler için JARVIS uygulamasını açın.")
        }
    }

    private fun setTorch(enabled: Boolean) {
        try {
            val camera = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) speak("Bu cihazda fener bulunamadı efendim.")
            else { camera.setTorchMode(id, enabled); speak(if (enabled) "Fener açıldı efendim." else "Fener kapatıldı efendim.") }
        } catch (_: Exception) { speak("Fener kontrol edilemedi efendim.") }
    }

    private fun scheduleListen(delay: Long) {
        if (destroyed) return
        handler.postDelayed({
            if (destroyed || speaking) { if (!destroyed) scheduleListen(700); return@postDelayed }
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                }
                recognizer?.startListening(intent)
            } catch (_: Exception) { scheduleListen(1200) }
        }, delay)
    }

    private fun speak(text: String) {
        if (ttsReady) {
            speaking = true
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_wake_reply")
            handler.postDelayed({ speaking = false }, 1800L + text.length * 55L)
        } else speaking = false
    }

    private fun stopSelfAfterSpeech() {
        handler.postDelayed({ stopSelf() }, 2500)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "JARVIS sesli uyandırma", NotificationManager.IMPORTANCE_LOW))
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("JARVIS aktif")
            .setContentText(message).setContentIntent(open).setOngoing(true).build()
        else Notification.Builder(this).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS aktif").setContentText(message).setContentIntent(open).setOngoing(true).build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(1001, buildNotification(message))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_COMMAND = "com.boss.jarvis.VOICE_COMMAND"
        const val EXTRA_COMMAND = "voice_command"
    }
}
