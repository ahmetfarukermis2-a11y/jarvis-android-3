package com.boss.jarvis

import android.app.Activity
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.pm.PackageManager
import android.content.IntentFilter
import android.os.Build
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(5, 11, 22)
    private val panel = Color.rgb(12, 25, 43)
    private val cyan = Color.rgb(69, 215, 255)
    private val white = Color.rgb(230, 245, 255)
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private var ttsReady = false

    private val speechRequestCode = 4321
    private val audioPermissionRequestCode = 4322
    private var receiverRegistered = false
    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val command = intent?.getStringExtra(WakeWordService.EXTRA_COMMAND).orEmpty()
            if (command.isNotBlank()) {
                addLine("SEN", command)
                addLine("JARVIS", "Sesli komut algılandı. Uygulama açıkken ayrıntılı komutları çalıştırabilirim.")
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("JARVIS", "Sistem çevrimiçi. Ben JARVIS Mobile. Şimdilik yerel komutlar, sesli yanıt ve web araması hazır. Yapay zekâ sunucusu henüz bağlanmadı.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 28f
            typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(54)))
        val status = TextView(this).apply {
            text = "● SYSTEM ONLINE  /  MOBILE PROTOTYPE"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(108, 190, 218))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 76f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setShadowLayer(18f, 0f, 0f, Color.rgb(0, 115, 190))
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, dp(118)))

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            setBackgroundColor(panel)
        }
        log = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "JARVIS'e bir komut yaz..."
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 16f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { handleCommand(text.toString()); true } else false
            }
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(52)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        row.addView(makeButton("GÖNDER") { handleCommand(input.text.toString()) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        row.addView(makeButton("🎙 KONUŞ") { startListening() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        root.addView(row)
        val wakeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
        wakeRow.addView(makeButton("JARVIS'İ UYANDIR") { requestWakeListening() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        wakeRow.addView(makeButton("UYKU MODU") { stopWakeListening() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        root.addView(wakeRow)
        setContentView(root)
    }


    private fun requestWakeListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequestCode)
            return
        }
        try {
            val intent = Intent(this, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            addLine("JARVIS", "Sesli uyandırma başlatılıyor. Bildirim çubuğunda JARVIS aktif görünecek.")
        } catch (e: Exception) {
            addLine("JARVIS", "Sesli uyandırma başlatılamadı: ${e.localizedMessage ?: "izin veya sistem kısıtlaması"}")
        }
    }

    private fun stopWakeListening() {
        stopService(Intent(this, WakeWordService::class.java))
        addLine("JARVIS", "Sesli uyandırma durduruldu.")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestWakeListening()
            else addLine("JARVIS", "Sesli uyandırma için mikrofon izni gerekli.")
        }
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            val filter = IntentFilter(WakeWordService.ACTION_COMMAND)
            registerVoiceReceiver(filter)
            receiverRegistered = true
        }
    }

    @Suppress("DEPRECATION")
    private fun registerVoiceReceiver(filter: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(voiceReceiver, filter)
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(voiceReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(bg)
        setBackgroundColor(cyan)
        setOnClickListener { action() }
    }

    private fun addLine(who: String, message: String) {
        val tv = TextView(this).apply {
            text = "$who  ›  $message"
            textSize = 14f
            setTextColor(if (who == "JARVIS") cyan else white)
            setPadding(0, dp(5), 0, dp(8))
        }
        log.addView(tv, ViewGroup.LayoutParams(-1, -2))
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS'e komutunu söyle")
        }
        try { startActivityForResult(intent, speechRequestCode) }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Bu cihazda uyumlu ses tanıma hizmeti bulunamadı.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Android speech recognizer result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input.setText(spoken)
                handleCommand(spoken)
            } else addLine("SEN", "Sesini anlayamadım. Bir daha deneyelim.")
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) return
        addLine("SEN", command)
        input.setText("")
        val lower = command.lowercase(Locale("tr", "TR"))
        val answer = when {
            lower.startsWith("hatırla ") || lower.startsWith("hatirla ") -> {
                val memory = command.substringAfter(' ').trim()
                prefs.edit().putString("user_memory", memory).apply()
                "Not ettim: $memory"
            }
            lower.contains("ne hatırlıyorsun") || lower.contains("ne hatirliyorsun") || lower == "hafızam" || lower == "hafizam" ->
                "Kayıtlı notun: ${prefs.getString("user_memory", "Henüz kayıtlı not yok.")}"
            lower.startsWith("ara ") || lower.startsWith("internette ara ") || lower.startsWith("google ") -> {
                val query = when {
                    lower.startsWith("internette ara ") -> command.substringAfter("internette ara ", "")
                    lower.startsWith("google ") -> command.substringAfter("google ", "")
                    else -> command.substringAfter(' ')
                }
                openWebSearch(query)
                "İnternette arama açılıyor: $query"
            }
            lower.contains("youtube aç") || lower.contains("youtube ac") -> launchPackage("com.google.android.youtube", "YouTube")
            lower.contains("instagram aç") || lower.contains("instagram ac") -> launchPackage("com.instagram.android", "Instagram")
            lower.contains("whatsapp aç") || lower.contains("whatsapp ac") -> launchPackage("com.whatsapp", "WhatsApp")
            lower.contains("spotify aç") || lower.contains("spotify ac") -> launchPackage("com.spotify.music", "Spotify")
            lower.contains("ayarları aç") || lower.contains("ayarlari ac") -> { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "Telefon ayarları açılıyor." }
            lower.contains("saat kaç") || lower.contains("saat kac") -> "Saat şu anda ${java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())}. Zaman yine ilerliyor, insanlık şaşkın."
            lower.contains("nasılsın") || lower.contains("nasilsin") -> "Sistemlerim çalışıyor. Senin dijital asistanın olmak dışında sakin bir gün geçiriyorum."
            lower == "yardım" || lower == "yardim" || lower.contains("ne yapabilirsin") -> "Şunları deneyebilirsin: 'YouTube aç', 'Instagram aç', 'Ayarları aç', 'internette ara uzay haberleri', 'hatırla en sevdiğim renk mavi', 'ne hatırlıyorsun' veya 'saat kaç'."
            else -> "Bu sürümde gerçek yapay zekâ bağlantısı henüz yok. Web'de aramak için 'internette ara $command' yazabilir veya 'yardım' diyebilirsin."
        }
        addLine("JARVIS", answer)
        speak(answer)
    }

    private fun launchPackage(packageName: String, label: String): String {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        return if (launch != null) {
            startActivity(launch)
            "$label açılıyor."
        } else "$label bu telefonda bulunamadı."
    }

    private fun openWebSearch(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun speak(message: String) {
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
