# JARVIS Mobile — Termux'ta yerel APK derleme

Bu paket, önceki Kotlin projesini korur. GitHub Actions kullanılmaz; APK doğrudan Android telefonda derlenir. Termux içinde Android SDK ve ARM64 uyumlu derleme araçları kurulmalıdır.

## Gerekenler
- ARM64 Android telefon (Redmi Note 15 uygun)
- F-Droid veya Termux'un resmi GitHub sürümünden güncel Termux uygulaması; Play Store'daki eski Termux sürümünü kullanma
- İnternet ve yaklaşık 3–5 GB boş alan
- İlk kurulumda sabır: SDK/Gradle paketleri epey büyük

## 1. Termux'u hazırla
Termux'u açıp sırayla çalıştır:

```bash
pkg update -y && pkg upgrade -y
pkg install -y git unzip
termux-setup-storage
```

Depolama izni sorulursa izin ver. Bu işlem dosyalarına erişmek içindir.

## 2. Telefonda Android derleme araçlarını kur
Aşağıdaki araç, Termux için ARM64 uyumlu Android derleme ortamını kurar. Bu, GitHub Actions kullanmak değildir ve bir GitHub hesabı gerektirmez; yalnızca kurulum dosyalarını indirir.

```bash
git clone https://github.com/poordevcode/termux-android-studio.git ~/termux-studio
bash ~/termux-studio/install.sh
source ~/.bashrc
studio doctor
```

Kurulum sırasında SDK/JDK indirilir; birkaç GB alan gerekebilir. Komut `studio doctor` hata verirse derlemeye geçme, önce ekrandaki eksik bileşeni düzelt.

## 3. ZIP dosyasını aç
Bu ZIP'i telefona indir. Ardından Termux'ta:

```bash
mkdir -p ~/jarvis
unzip ~/storage/downloads/JARVIS_Termux.zip -d ~/jarvis
```

Dosya adın farklıysa komutta ZIP adını değiştir. Proje yolu şu olmalı:

```bash
ls ~/jarvis/jarvis_android/app/src/main/java/com/boss/jarvis/MainActivity.kt
```

## 4. APK'yı derle

```bash
studio build ~/jarvis/jarvis_android
```

İlk derleme, Gradle bağımlılıklarını indirdiği için uzun sürebilir. Başarılı olursa APK normalde şurada oluşur:

```text
~/jarvis/jarvis_android/app/build/outputs/apk/debug/app-debug.apk
```

APK'yı İndirilenler klasörüne kopyala:

```bash
cp ~/jarvis/jarvis_android/app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/JARVIS-debug.apk
```

Sonra Dosya Yöneticisi > İndirilenler > `JARVIS-debug.apk` dosyasına dokunup Android'in kurulum adımlarını uygula. İstenirse yalnızca kullandığın dosya yöneticisi için “bilinmeyen uygulamaları yükle” iznini aç.

## 5. Derleme başarısız olursa
Hata mesajının son 30–50 satırını kopyala:

```bash
studio build ~/jarvis/jarvis_android 2>&1 | tee ~/jarvis-build.log
 tail -n 50 ~/jarvis-build.log
```

Çıktıyı gönder; özellikle `aapt2`, `SDK location`, `compileSdk` veya `Gradle` yazan satırlar sorunun yerini gösterir.

## JARVIS'in bu sürümündeki özellikler
- Türkçe konuşmayı Android konuşma tanıma servisiyle metne çevirme
- Android TTS ile sesli yanıt
- YouTube, Instagram, WhatsApp, Spotify ve Ayarlar'ı açma denemeleri
- Google araması
- `hatırla ...` ile tek yerel not ve `ne hatırlıyorsun` komutu
- Koyu mavi JARVIS arayüzü

Gerçek bulut yapay zekâ bağlantısı ve arka planda sürekli “Hey JARVIS” dinleme bu sürümde yok. Uygulama APK olarak derlense bile bu özellikler kendiliğinden ortaya çıkmıyor; keşke yazılım böyle çalışsaydı.
