# JARVIS Mobile (Android Kotlin)

Redmi Note 15 ve diğer Android telefonlar için Kotlin tabanlı JARVIS prototipi.

## Özellikler
- Türkçe sesli komut girişi (uygulama içindeki KONUŞ düğmesi).
- Android TextToSpeech ile Türkçe sesli yanıt (cihazda Türkçe ses verisi varsa).
- YouTube, Instagram, WhatsApp, Spotify ve Ayarlar uygulamalarını açma.
- Google araması açma.
- `hatırla ...` ile tek yerel not saklama ve `ne hatırlıyorsun` ile okuma.
- Koyu, mavi JARVIS arayüzü.
- **JARVIS'İ UYANDIR** düğmesiyle kullanıcı tarafından başlatılan foreground mikrofon servisi.
- Servis aktifken “JARVIS” veya “Hey JARVIS” uyandırma ifadesi, ardından sesli komut.
- Serviste temel saat, pil seviyesi ve fener komutları.
- **UYKU MODU** düğmesi veya sesli uyku komutuyla dinlemeyi durdurma.
- Kalıcı bildirimle mikrofon servisinin çalıştığını gösterme.

## Önemli Android sınırlamaları
- Bu prototip, Android'in konuşma tanıma hizmetini kullanır. Çevrimdışı tanıma cihazdaki hizmete bağlıdır; `EXTRA_PREFER_OFFLINE` bir garanti değildir.
- Ekran kapalıyken veya pil tasarrufu açıkken Xiaomi/Android servisi durdurabilir. Her cihazda kesintisiz hotword garantisi verilemez.
- Servis yalnızca uygulama görünürken kullanıcı tarafından başlatılır; Android'in arka plan mikrofon kısıtlamalarını aşmaya çalışmaz.
- Ekran kilitliyken uygulama açma gibi işlemler için telefonun kilidini açmak gerekir.
- Gerçek bulut yapay zekâ bağlantısı henüz yoktur. API anahtarları APK içine gömülmemelidir.
- Arayüz bu başlangıç projesinde Android View bileşenleri kullanır; Jetpack Compose'a henüz taşınmamıştır.

## Derleme
Android Studio'da bu klasörü proje olarak aç, Gradle eşitlemesini tamamla ve `app > Tasks > build > assembleDebug` çalıştır. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` yolunda oluşur.

Bu çalışma ortamında Android SDK bulunmadığından APK burada derlenip doğrulanamadı. ZIP, güncellenmiş kaynak projedir; hazır APK değildir.
